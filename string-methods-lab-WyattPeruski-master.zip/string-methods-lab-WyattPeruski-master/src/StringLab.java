import java.util.Arrays;
public class StringLab {
public static void main(String[] args) {
	capitalize("grEEn");
	wheresWaldo("where's Waldo");
	firstThingsFirst("Beans ", "House ");
	reverse("Doggie");
	soLong("Dog","No");
	afterMath("I finished my math homework");
	letterSize("someString");
}	

public static void capitalize(String word) {
	String InputFirstLetter = word.substring(0,1);
	String InputLastLetters = word.substring(1);
	
	InputFirstLetter = InputFirstLetter.toUpperCase();
	InputLastLetters = InputLastLetters.toLowerCase();
	
	word = InputFirstLetter + InputLastLetters;
	
	System.out.println(word);
}
public static void wheresWaldo(String phrase) {
	
	System.out.println(phrase.indexOf("Waldo"));
			
	
	
}

public static void firstThingsFirst(String a, String b) {
	
	
	if(a.compareTo(b) > 0) {
		System.out.println(b + a);
	}
	else if (b.compareTo(a) > 0) {
		System.out.println(a + b);
	}
}

	


public static void reverse(String s) {
	String reverseString = "";
	
	int i;
	for(i = s.length() - 1; i >= 0; i-- ){
		reverseString = reverseString + s.charAt(i);
	}
	System.out.println(reverseString);
}

public static void soLong(String a, String b) {
	if(a.length() > b.length()) {
		System.out.println(a);
	}
	else if(a.length() == b.length()) {
		System.out.println(a + b);
	}
	else {
		System.out.println(b);
	}
	
}

public static void afterMath(String Phrase) {
	if(Phrase.contains("math")) {
		int Index = Phrase.indexOf("math");
		Phrase = Phrase.substring(Index);
		System.out.println(Phrase);
	}
	else {
		System.out.println("dud");
	}
	
	
}

public static void letterSize(String word) {
	
	word = "someString";
	for (int i = 0; i < word.length(); i++) {
	    System.out.println(word.charAt(i));
	    
	}
	
}
}
