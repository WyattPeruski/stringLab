# String Methods Lab

## Instructions
[Instructions.pdf](Instructions.pdf)

## Setup
1. **Clone** this repository in your Eclipse workspace.
2. In Eclipse, select **new Java Project**
3. In the dialog window, **uncheck "Use default location"**.
4. For location, click **Browse**. Select the new folder that was created by the clone.
5. Click finish.
6. If asked, do NOT create a module.

Add your code in the `src` folder. (Note: there is a .keep file there, which is there to preserve the src folder in GitHub. You can leave it or delete it if you like.) 

## Submission
Add, commit, and push your changes.
